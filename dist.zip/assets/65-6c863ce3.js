const e=""+new URL("3d/image/65.png",import.meta.url).href;export{e as _};
