const workfacePopup_shuanglong = [
  { name: '107综采工作面', position: { x: 181, y: 0, z: -271 } },
  { name: '112综采工作面', position: { x: -21, y: 0, z: -267 } },
  { name: '113综采工作面', position: { x: -10, y: 0, z: -229 } },
  { name: '108综采工作面', position: { x: -101, y: 0, z: -179 } },
  { name: '109综采工作面', position: { x: -168, y: 0, z: -192 } },
  { name: '110备采工作面', position: { x: -190, y: 0, z: -159 } },
  { name: '106综采工作面', position: { x: -76, y: 0, z: -51 } },
  { name: '105综采工作面', position: { x: -86, y: 0, z: -11 } },
  { name: '104综采工作面', position: { x: -81, y: 0, z: 31 } },
  { name: '103综采工作面', position: { x: -81, y: 0, z: 65 } },
  { name: '102综采工作面', position: { x: -93, y: 0, z: 96 } },
  { name: '101综采工作面', position: { x: -101, y: 0, z: 124 } },
  { name: '一号永久避难硐室', position: { x: 17, y: 0, z: 17 } },
  { name: '中央变电所', position: { x: -13, y: 0, z: 294 } },
  { name: '中央水泵房', position: { x: -12, y: 0, z: 287 } },
  { name: '盘区水泵房', position: { x: 28, y: 0, z: -57 } },
  { name: '盘区变电所', position: { x: 29, y: 0, z: -62 } },
  { name: '101运顺掘进工作面', position: { x: -23, y: 0, z: 113 } },
  { name: '101回顺掘进工作面', position: { x: -72, y: 0, z: 110 } },
  { name: '瓦斯抽采泵站', position: { x: -49, y: 0, z: 190 } },
  { name: '副斜井主扇', position: { x: -61, y: 0, z: 223 } },
  { name: '副斜井压风机', position: { x: -51, y: 0, z: 213 } }
]

window.workfacePopup_shuanglong = workfacePopup_shuanglong